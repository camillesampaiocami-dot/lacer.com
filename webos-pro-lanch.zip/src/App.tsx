/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Monitor, Smartphone, Download } from 'lucide-react';
import Desktop from './Desktop';
import Mobile from './Mobile';
import BootScreen from './components/BootScreen';
import DownloadPage from './components/DownloadPage';
import { Language } from './translations';

export default function App() {
  const [isBooting, setIsBooting] = useState(true);
  const [showDownloadPage, setShowDownloadPage] = useState(() => {
    return !localStorage.getItem('webos_entered');
  });
  const [mode, setMode] = useState<'desktop' | 'mobile'>('desktop');
  const [language, setLanguage] = useState<Language>('pt');
  const [initialApp, setInitialApp] = useState<AppId | null>(null);

  const enterSystem = (startApp?: AppId) => {
    localStorage.setItem('webos_entered', 'true');
    if (startApp) setInitialApp(startApp);
    setShowDownloadPage(false);
  };

  if (isBooting) {
    return <BootScreen onComplete={() => setIsBooting(false)} />;
  }

  if (showDownloadPage) {
    return <DownloadPage language={language} onBack={enterSystem} />;
  }

  return (
    <div className="h-screen w-screen overflow-hidden bg-zinc-950 relative">
      {/* Mode Switcher Overlay */}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[99999] flex items-center gap-2 bg-white/10 backdrop-blur-xl p-1.5 rounded-full border border-white/10 shadow-2xl">
        <button 
          onClick={() => setMode('desktop')}
          className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-bold transition-all ${mode === 'desktop' ? 'bg-blue-500 text-white shadow-lg' : 'text-white/50 hover:text-white'}`}
        >
          <Monitor size={16} /> Desktop
        </button>
        <button 
          onClick={() => setMode('mobile')}
          className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-bold transition-all ${mode === 'mobile' ? 'bg-blue-500 text-white shadow-lg' : 'text-white/50 hover:text-white'}`}
        >
          <Smartphone size={16} /> Mobile
        </button>
        <div className="w-[1px] h-6 bg-white/10 mx-1" />
        <button 
          onClick={() => setShowDownloadPage(true)}
          className="flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-bold text-white/50 hover:text-white transition-all"
        >
          <Download size={16} /> Site
        </button>
      </div>

      <AnimatePresence mode="wait">
        {mode === 'desktop' ? (
          <motion.div
            key="desktop"
            initial={{ opacity: 0, scale: 1.1, filter: 'blur(20px)' }}
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 0.9, filter: 'blur(20px)' }}
            transition={{ duration: 0.5, ease: 'easeInOut' }}
            className="h-full w-full"
          >
            <Desktop language={language} setLanguage={setLanguage} initialApp={initialApp} />
          </motion.div>
        ) : (
          <motion.div
            key="mobile"
            initial={{ opacity: 0, scale: 0.9, filter: 'blur(20px)' }}
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 1.1, filter: 'blur(20px)' }}
            transition={{ duration: 0.5, ease: 'easeInOut' }}
            className="h-full w-full bg-zinc-900"
          >
            <Mobile language={language} setLanguage={setLanguage} initialApp={initialApp} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
