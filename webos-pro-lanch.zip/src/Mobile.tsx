import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wifi, Battery, Signal, Search, 
  LayoutGrid, Settings, Folder, FileText, 
  Calculator as CalcIcon, Terminal as TerminalIcon,
  ShoppingBag, ChevronLeft, Home, Menu,
  Bell, Moon, Bluetooth, Sun, Volume2,
  Lock, Camera, Mic, Image as ImageIcon, Music, Calendar as CalendarIcon, Clock, Globe
} from 'lucide-react';
import { AppId } from './types';
import { 
  Notepad, Calculator, Terminal, PlayStore, SettingsApp, Explorer,
  CameraApp, GalleryApp, MusicApp, BrowserApp, CalendarApp, ClockApp
} from './components/Apps';
import { Language, translations } from './translations';

const getMobileApps = (language: Language) => [
  { id: 'terminal', name: translations[language].apps.terminal.title, icon: <TerminalIcon />, color: 'bg-zinc-900', component: Terminal },
  { id: 'notepad', name: translations[language].mobile.notes, icon: <FileText />, color: 'bg-orange-500', component: Notepad },
  { id: 'calculator', name: translations[language].mobile.calc, icon: <CalcIcon />, color: 'bg-blue-600', component: Calculator },
  { id: 'explorer', name: translations[language].mobile.files, icon: <Folder />, color: 'bg-blue-400', component: Explorer },
  { id: 'playstore', name: translations[language].mobile.store, icon: <ShoppingBag />, color: 'bg-emerald-500', component: PlayStore },
  { id: 'camera', name: translations[language].mobile.camera, icon: <Camera />, color: 'bg-zinc-700', component: CameraApp },
  { id: 'gallery', name: translations[language].mobile.gallery, icon: <ImageIcon />, color: 'bg-blue-500', component: GalleryApp },
  { id: 'music', name: translations[language].mobile.music, icon: <Music />, color: 'bg-rose-500', component: MusicApp },
  { id: 'browser', name: translations[language].mobile.browser, icon: <Globe />, color: 'bg-blue-600', component: BrowserApp },
  { id: 'calendar', name: translations[language].mobile.calendar, icon: <CalendarIcon />, color: 'bg-red-500', component: CalendarApp },
  { id: 'clock', name: translations[language].mobile.clock, icon: <Clock />, color: 'bg-zinc-800', component: ClockApp },
  { id: 'settings', name: translations[language].mobile.settings, icon: <Settings />, color: 'bg-gray-500', component: SettingsApp },
];

export default function Mobile({ language, setLanguage, initialApp }: { language: Language, setLanguage: (l: Language) => void, initialApp: AppId | null }) {
  const t = translations[language];
  const MOBILE_APPS = getMobileApps(language);
  const [activeApp, setActiveApp] = useState<AppId | null>(null);
  const [isLocked, setIsLocked] = useState(true);
  const [showControlCenter, setShowControlCenter] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [wallpaper, setWallpaper] = useState('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1080&q=80');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    
    // Handle initial app
    if (initialApp) {
      setIsLocked(false);
      setActiveApp(initialApp);
    }

    return () => clearInterval(timer);
  }, [initialApp]);

  const openApp = (id: AppId) => {
    setActiveApp(id);
  };

  const closeApp = () => {
    setActiveApp(null);
  };

  const toggleControlCenter = () => {
    setShowControlCenter(!showControlCenter);
  };

  return (
    <div className="h-screen w-screen bg-black flex items-center justify-center font-sans overflow-hidden">
      {/* Phone Frame (Optional, but looks better for "Android version" demo) */}
      <div className="relative w-full h-full max-w-[430px] max-h-[932px] bg-black rounded-[60px] shadow-2xl overflow-hidden border-[8px] border-zinc-800 flex flex-col">
        
        {/* Wallpaper */}
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-700"
          style={{ backgroundImage: `url(${wallpaper})`, filter: activeApp ? 'blur(20px) brightness(0.5)' : 'none' }}
        />

        {/* Status Bar (iOS Style) */}
        <div className="h-12 flex items-center justify-between px-8 z-[100] text-white text-sm font-semibold">
          <div className="flex-1">
            {currentTime.toLocaleTimeString(language === 'pt' ? 'pt-BR' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
          </div>
          {/* Dynamic Island Area */}
          <div className="w-32 h-7 bg-black rounded-full mx-auto" />
          <div className="flex-1 flex justify-end items-center gap-1.5">
            <Signal size={14} />
            <Wifi size={14} />
            <Battery size={14} className="rotate-90" />
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-grow relative overflow-hidden">
          
          {/* Lock Screen */}
          <AnimatePresence>
            {isLocked && (
              <motion.div 
                initial={{ y: 0 }}
                exit={{ y: '-100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="absolute inset-0 z-[200] flex flex-col items-center justify-between py-20 bg-black/20 backdrop-blur-sm"
              >
                <div className="text-center text-white">
                  <Lock className="mx-auto mb-4 opacity-50" size={32} />
                  <h1 className="text-7xl font-thin tracking-tight">
                    {currentTime.toLocaleTimeString(language === 'pt' ? 'pt-BR' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
                  </h1>
                  <p className="text-xl font-medium opacity-80 mt-2 capitalize">
                    {currentTime.toLocaleDateString(language === 'pt' ? 'pt-BR' : 'en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                  </p>
                </div>

                <div className="flex flex-col items-center gap-8">
                  <motion.div 
                    animate={{ y: [0, -10, 0] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="text-white/60 text-sm font-medium"
                  >
                    {t.mobile.swipeToUnlock}
                  </motion.div>
                  <button 
                    onClick={() => setIsLocked(false)}
                    className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/20"
                  >
                    <ChevronLeft className="rotate-90" />
                  </button>
                </div>

                <div className="w-full px-10 flex justify-between">
                  <div className="w-12 h-12 bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center text-white">
                    <Camera size={20} />
                  </div>
                  <div className="w-12 h-12 bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center text-white">
                    <Mic size={20} />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Home Screen (Android Style Grid) */}
          <div className="h-full w-full p-6 grid grid-cols-4 grid-rows-5 gap-y-8 content-start">
            {MOBILE_APPS.map((app, i) => (
              <motion.button
                key={app.id}
                whileTap={{ scale: 0.9 }}
                onClick={() => openApp(app.id as AppId)}
                className="flex flex-col items-center gap-2"
              >
                <div className={`w-16 h-16 ${app.color} rounded-[22%] flex items-center justify-center text-white shadow-lg`}>
                  {React.cloneElement(app.icon as React.ReactElement, { size: 32 })}
                </div>
                <span className="text-white text-[11px] font-medium drop-shadow-md">{app.name}</span>
              </motion.button>
            ))}
          </div>

          {/* Dock (iOS Style) */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-[90%] h-24 bg-white/20 backdrop-blur-2xl rounded-[35px] border border-white/10 flex items-center justify-around px-4">
            {MOBILE_APPS.slice(0, 4).map(app => (
              <motion.button
                key={app.id}
                whileTap={{ scale: 0.9 }}
                onClick={() => openApp(app.id as AppId)}
                className={`w-16 h-16 ${app.color} rounded-[22%] flex items-center justify-center text-white shadow-lg`}
              >
                {React.cloneElement(app.icon as React.ReactElement, { size: 32 })}
              </motion.button>
            ))}
          </div>

          {/* Control Center (Pull Down) */}
          <AnimatePresence>
            {showControlCenter && (
              <motion.div
                initial={{ y: '-100%' }}
                animate={{ y: 0 }}
                exit={{ y: '-100%' }}
                className="absolute inset-0 z-[300] bg-zinc-900/80 backdrop-blur-3xl p-8 pt-20"
              >
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="bg-white/10 p-4 rounded-3xl grid grid-cols-2 gap-4">
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white"><Wifi size={20} /></div>
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white"><Bluetooth size={20} /></div>
                    <div className="w-12 h-12 bg-zinc-700 rounded-full flex items-center justify-center text-white"><Signal size={20} /></div>
                    <div className="w-12 h-12 bg-zinc-700 rounded-full flex items-center justify-center text-white"><Bell size={20} /></div>
                  </div>
                  <div className="bg-white/10 p-4 rounded-3xl flex flex-col justify-between">
                    <div className="flex items-center gap-3 text-white">
                      <Moon size={20} className="text-indigo-400" />
                      <span className="text-sm font-medium">{t.mobile.focus}</span>
                    </div>
                    <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full w-2/3 bg-white" />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/10 p-4 rounded-3xl flex flex-col gap-4">
                    <Sun size={20} className="text-yellow-400" />
                    <div className="h-32 w-full bg-white/10 rounded-2xl relative overflow-hidden">
                      <div className="absolute bottom-0 w-full h-1/2 bg-white" />
                    </div>
                  </div>
                  <div className="bg-white/10 p-4 rounded-3xl flex flex-col gap-4">
                    <Volume2 size={20} className="text-blue-400" />
                    <div className="h-32 w-full bg-white/10 rounded-2xl relative overflow-hidden">
                      <div className="absolute bottom-0 w-full h-3/4 bg-white" />
                    </div>
                  </div>
                </div>

                <button 
                  onClick={toggleControlCenter}
                  className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/50"
                >
                  <ChevronLeft className="rotate-90" size={32} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Active App Layer */}
          <AnimatePresence>
            {activeApp && (
              <motion.div
                initial={{ scale: 0, borderRadius: '60px', opacity: 0 }}
                animate={{ scale: 1, borderRadius: '0px', opacity: 1 }}
                exit={{ scale: 0, borderRadius: '60px', opacity: 0 }}
                className="absolute inset-0 z-[400] bg-white flex flex-col"
              >
                <div className="h-12 flex items-center justify-between px-6 bg-gray-100 border-b">
                  <button onClick={closeApp} className="text-blue-500 font-medium flex items-center gap-1">
                    <ChevronLeft size={20} /> {t.mobile.back}
                  </button>
                  <span className="font-bold text-gray-800">
                    {MOBILE_APPS.find(a => a.id === activeApp)?.name}
                  </span>
                  <div className="w-10" />
                </div>
                <div className="flex-grow overflow-hidden">
                  {(() => {
                    const AppComp = MOBILE_APPS.find(a => a.id === activeApp)?.component;
                    return AppComp ? <AppComp onWallpaperChange={setWallpaper} language={language} setLanguage={setLanguage} /> : null;
                  })()}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </div>

        {/* Navigation Bar (Android/iOS Hybrid) */}
        <div className="h-16 bg-black/20 backdrop-blur-md flex items-center justify-center relative">
          {/* iOS Style Gesture Bar */}
          <button 
            onClick={closeApp}
            className="w-32 h-1.5 bg-white/40 rounded-full hover:bg-white/60 transition-colors"
          />
          
          {/* Android Style Quick Access (Hidden by default, triggered by swipe) */}
          <div className="absolute right-8 flex items-center gap-6 text-white/30">
             <button onClick={toggleControlCenter}><Menu size={20} /></button>
          </div>
          <div className="absolute left-8 flex items-center gap-6 text-white/30">
             <button onClick={() => setIsLocked(true)}><Home size={20} /></button>
          </div>
        </div>

      </div>
    </div>
  );
}
