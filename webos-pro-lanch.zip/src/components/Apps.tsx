import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, Calculator as CalcIcon, Folder, Settings, 
  Terminal as TerminalIcon, Search, Star, Info, Palette, Monitor,
  ChevronRight, Download, Smartphone, Globe, Camera, Image as ImageIcon,
  Music, Calendar as CalendarIcon, Clock, RefreshCw, SkipBack, SkipForward, Play, ChevronLeft
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { Language, translations } from '../translations';

// --- App Components ---

export const Notepad: React.FC<{ language: Language }> = ({ language }) => {
  const [text, setText] = useState('');
  const t = translations[language].apps.notepad;
  return (
    <textarea 
      className="w-full h-full p-4 bg-white text-gray-800 outline-none resize-none font-mono"
      placeholder={t.placeholder}
      value={text}
      onChange={(e) => setText(e.target.value)}
    />
  );
};

export const Calculator: React.FC<{ language: Language }> = ({ language }) => {
  const [display, setDisplay] = useState('0');
  const t = translations[language].apps.calculator;
  const buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+'
  ];

  const handleBtn = (btn: string) => {
    if (btn === '=') {
      try {
        setDisplay(eval(display).toString());
      } catch {
        setDisplay(t.error);
      }
    } else if (display === '0' || display === t.error) {
      setDisplay(btn);
    } else {
      setDisplay(display + btn);
    }
  };

  return (
    <div className="p-4 bg-gray-100 h-full flex flex-col">
      <div className="bg-white p-4 text-right text-2xl font-mono mb-4 rounded shadow-inner overflow-hidden">
        {display}
      </div>
      <div className="grid grid-cols-4 gap-2 flex-grow">
        {buttons.map(b => (
          <button 
            key={b} 
            onClick={() => handleBtn(b)}
            className="bg-white hover:bg-gray-200 p-4 rounded shadow-sm text-lg font-bold transition-colors"
          >
            {b}
          </button>
        ))}
        <button 
          onClick={() => setDisplay('0')}
          className="col-span-4 bg-red-500 text-white p-2 rounded mt-2 hover:bg-red-600 transition-colors"
        >
          {t.clear}
        </button>
      </div>
    </div>
  );
};

export const Terminal: React.FC<{ language: Language }> = ({ language }) => {
  const t = translations[language].apps.terminal;
  const [history, setHistory] = useState<string[]>([t.welcome, t.help]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history]);

  const handleCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const cmd = input.trim();
    setHistory(prev => [...prev, `> ${cmd}`]);
    setInput('');

    if (cmd.toLowerCase() === 'help') {
      setHistory(prev => [...prev, t.availableCmds]);
    } else if (cmd.toLowerCase() === 'clear') {
      setHistory([]);
    } else if (cmd.toLowerCase() === 'date') {
      setHistory(prev => [...prev, new Date().toLocaleString()]);
    } else if (cmd.toLowerCase().startsWith('echo ')) {
      setHistory(prev => [...prev, cmd.substring(5)]);
    } else if (cmd.toLowerCase().startsWith('ai ')) {
      const prompt = cmd.substring(3);
      setHistory(prev => [...prev, t.thinking]);
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: prompt,
        });
        setHistory(prev => [...prev.slice(0, -1), `AI: ${response.text}`]);
      } catch (err) {
        setHistory(prev => [...prev.slice(0, -1), 'Error: AI service unavailable.']);
      }
    } else {
      setHistory(prev => [...prev, `${t.cmdNotFound} ${cmd}`]);
    }
  };

  return (
    <div className="bg-black text-green-500 font-mono p-4 h-full flex flex-col overflow-hidden">
      <div className="flex-grow overflow-y-auto mb-2" ref={scrollRef}>
        {history.map((line, i) => (
          <div key={i} className="whitespace-pre-wrap mb-1">{line}</div>
        ))}
      </div>
      <form onSubmit={handleCommand} className="flex">
        <span className="mr-2">$</span>
        <input 
          autoFocus
          className="bg-transparent outline-none flex-grow"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
      </form>
    </div>
  );
};

export const PlayStore: React.FC<{ language: Language }> = ({ language }) => {
  const t = translations[language].apps.playstore;
  const [installing, setInstalling] = useState<string | null>(null);
  const [installed, setInstalled] = useState<string[]>([]);

  const apps = [
    { id: 'instagram', name: 'Instagram', category: 'Social', rating: 4.8, icon: <div className="w-10 h-10 bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600 rounded-lg flex items-center justify-center text-white text-[10px] font-bold">IG</div> },
    { id: 'spotify', name: 'Spotify', category: 'Music', rating: 4.9, icon: <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center text-white text-[10px] font-bold">SP</div> },
    { id: 'whatsapp', name: 'WhatsApp', category: 'Communication', rating: 4.7, icon: <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center text-white text-[10px] font-bold">WA</div> },
    { id: 'netflix', name: 'Netflix', category: 'Entertainment', rating: 4.6, icon: <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center text-white text-[10px] font-bold">NF</div> },
    { id: 'youtube', name: 'YouTube', category: 'Video', rating: 4.8, icon: <div className="w-10 h-10 bg-red-500 rounded-lg flex items-center justify-center text-white text-[10px] font-bold">YT</div> },
    { id: 'twitter', name: 'X (Twitter)', category: 'Social', rating: 4.2, icon: <div className="w-10 h-10 bg-black rounded-lg flex items-center justify-center text-white text-[10px] font-bold">X</div> },
  ];

  const handleInstall = (id: string) => {
    if (installed.includes(id)) return;
    setInstalling(id);
    setTimeout(() => {
      setInstalling(null);
      setInstalled(prev => [...prev, id]);
    }, 2000);
  };

  return (
    <div className="bg-gray-50 h-full flex flex-col overflow-hidden">
      <div className="bg-white p-4 border-b flex items-center gap-4">
        <div className="flex-grow bg-gray-100 px-4 py-2 rounded-full flex items-center gap-2 text-gray-500 text-sm">
          <Search size={16} />
          <span>{t.search}</span>
        </div>
        <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">R</div>
      </div>
      
      <div className="flex-grow overflow-y-auto p-4">
        <div className="flex gap-4 mb-8 overflow-x-auto pb-2 scrollbar-hide">
          {t.categories.map((tab, i) => (
            <button key={tab} className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap ${i === 0 ? 'bg-green-100 text-green-800' : 'text-gray-600 hover:bg-gray-200'}`}>
              {tab}
            </button>
          ))}
        </div>

        <h3 className="text-lg font-bold text-gray-800 mb-4">{t.recommended}</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {apps.map(app => (
            <div key={app.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 hover:bg-gray-50 transition-colors cursor-pointer group">
              {app.icon}
              <div className="flex-grow min-w-0">
                <h4 className="font-bold text-gray-800 truncate">{app.name}</h4>
                <p className="text-xs text-gray-500">{app.category}</p>
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-xs font-medium text-gray-700">{app.rating}</span>
                  <Star size={10} className="text-yellow-400 fill-yellow-400" />
                </div>
              </div>
              <button 
                onClick={() => handleInstall(app.id)}
                disabled={installing === app.id || installed.includes(app.id)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                  installed.includes(app.id) 
                    ? 'bg-gray-100 text-gray-500 cursor-default' 
                    : installing === app.id 
                      ? 'bg-green-100 text-green-600 animate-pulse' 
                      : 'bg-green-600 text-white hover:bg-green-700'
                }`}
              >
                {installed.includes(app.id) ? 'Abri' : installing === app.id ? '...' : t.install}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export const SettingsApp: React.FC<{ 
  language: Language, 
  setLanguage: (l: Language) => void, 
  onWallpaperChange: (url: string) => void 
}> = ({ language, setLanguage, onWallpaperChange }) => {
  const t = translations[language].apps.settings;
  const wallpapers = [
    'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1920&q=80',
    'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80',
    'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1920&q=80',
    'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1920&q=80',
    'https://images.unsplash.com/photo-1536431311719-398b6704d4cc?auto=format&fit=crop&w=1920&q=80',
  ];

  const [activeTab, setActiveTab] = useState<'personalization' | 'language' | 'build'>('personalization');

  return (
    <div className="bg-gray-50 h-full flex">
      <div className="w-48 bg-white border-r p-4 flex flex-col gap-2">
        <button 
          onClick={() => setActiveTab('personalization')}
          className={`flex items-center gap-3 p-2 rounded-lg text-sm font-medium transition-colors ${activeTab === 'personalization' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100 text-gray-600'}`}
        >
          <Monitor size={18} /> {t.personalization}
        </button>
        <button 
          onClick={() => setActiveTab('language')}
          className={`flex items-center gap-3 p-2 rounded-lg text-sm font-medium transition-colors ${activeTab === 'language' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100 text-gray-600'}`}
        >
          <Globe size={18} /> {t.language}
        </button>
        <button 
          onClick={() => setActiveTab('build')}
          className={`flex items-center gap-3 p-2 rounded-lg text-sm font-medium transition-colors ${activeTab === 'build' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100 text-gray-600'}`}
        >
          <Download size={18} /> {t.buildExport}
        </button>
        <button className="flex items-center gap-3 p-2 hover:bg-gray-100 rounded-lg text-sm text-gray-600 mt-auto">
          <Info size={18} /> {t.about}
        </button>
      </div>
      <div className="flex-grow p-8 overflow-y-auto">
        <div className="max-w-2xl">
          {activeTab === 'personalization' && (
            <>
              <h2 className="text-2xl font-bold mb-6 text-gray-800">{t.personalization}</h2>
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">{t.background}</h3>
              <div className="grid grid-cols-2 gap-4">
                {wallpapers.map((url, i) => (
                  <button 
                    key={i} 
                    onClick={() => onWallpaperChange(url)}
                    className="aspect-video rounded-xl overflow-hidden border-2 border-transparent hover:border-blue-500 transition-all shadow-sm group relative"
                  >
                    <img src={url} alt="wallpaper" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                  </button>
                ))}
              </div>
            </>
          )}

          {activeTab === 'language' && (
            <>
              <h2 className="text-2xl font-bold mb-6 text-gray-800">{t.language}</h2>
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">{t.selectLanguage}</h3>
              <div className="grid grid-cols-1 gap-3">
                <button 
                  onClick={() => setLanguage('en')}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all ${language === 'en' ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' : 'border-gray-200 bg-white hover:border-gray-300'}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">🇺🇸</span>
                    <span className="font-medium text-gray-800">English</span>
                  </div>
                  {language === 'en' && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                </button>
                <button 
                  onClick={() => setLanguage('pt')}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all ${language === 'pt' ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' : 'border-gray-200 bg-white hover:border-gray-300'}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">🇧🇷</span>
                    <span className="font-medium text-gray-800">Português</span>
                  </div>
                  {language === 'pt' && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                </button>
              </div>
            </>
          )}

          {activeTab === 'build' && (
            <>
              <h2 className="text-2xl font-bold mb-6 text-gray-800">{t.buildExport}</h2>
              <div className="space-y-6">
                <section className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-green-100 text-green-600 rounded-xl flex items-center justify-center">
                      <Smartphone size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800">{t.androidApk}</h3>
                      <p className="text-xs text-gray-500">{t.generateApk}</p>
                    </div>
                  </div>
                  <div className="bg-gray-900 rounded-xl p-4 font-mono text-xs text-green-400 mb-4">
                    npm run build:android
                  </div>
                </section>

                <section className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
                      <Monitor size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800">{t.windowsExe}</h3>
                      <p className="text-xs text-gray-500">{t.generateExe}</p>
                    </div>
                  </div>
                  <div className="bg-gray-900 rounded-xl p-4 font-mono text-xs text-blue-400 mb-4">
                    npm run build:windows
                  </div>
                </section>

                <div className="flex items-center gap-3 p-4 bg-amber-50 rounded-xl border border-amber-100">
                  <Info className="text-amber-500" size={20} />
                  <p className="text-xs text-amber-800">
                    {t.buildNote}
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export const CameraApp: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="bg-black h-full flex items-center justify-center relative overflow-hidden">
      <div className="w-64 h-64 border-2 border-white/20 rounded-full flex items-center justify-center">
        <div className="w-48 h-48 border border-white/10 rounded-full flex items-center justify-center">
           <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse" />
        </div>
      </div>
      <div className="absolute bottom-8 left-0 right-0 flex justify-center gap-8 items-center">
        <div className="w-12 h-12 bg-white/10 rounded-full border border-white/20" />
        <button className="w-20 h-20 bg-white rounded-full border-4 border-gray-300 active:scale-90 transition-transform" />
        <div className="w-12 h-12 bg-white/10 rounded-full border border-white/20 flex items-center justify-center">
           <RefreshCw className="text-white" size={20} />
        </div>
      </div>
    </div>
  );
};

export const GalleryApp: React.FC<{ language: Language }> = ({ language }) => {
  const images = [
    'https://picsum.photos/seed/nature/400/400',
    'https://picsum.photos/seed/city/400/400',
    'https://picsum.photos/seed/tech/400/400',
    'https://picsum.photos/seed/people/400/400',
    'https://picsum.photos/seed/animals/400/400',
    'https://picsum.photos/seed/food/400/400',
  ];
  return (
    <div className="bg-white h-full p-4 overflow-y-auto">
      <div className="grid grid-cols-3 gap-2">
        {images.map((url, i) => (
          <div key={i} className="aspect-square rounded-lg overflow-hidden bg-gray-100">
            <img src={url} alt="gallery" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
        ))}
      </div>
    </div>
  );
};

export const MusicApp: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="bg-zinc-900 h-full flex flex-col p-6 text-white">
      <div className="flex-grow flex flex-col items-center justify-center gap-8">
        <div className="w-64 h-64 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl shadow-2xl flex items-center justify-center">
          <Music size={80} />
        </div>
        <div className="text-center">
          <h2 className="text-2xl font-bold">Lanch Beats</h2>
          <p className="text-zinc-400">WebOS Originals</p>
        </div>
      </div>
      <div className="space-y-6">
        <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
          <div className="h-full bg-blue-500 w-1/3" />
        </div>
        <div className="flex justify-between items-center px-4">
          <SkipBack size={24} />
          <div className="w-16 h-16 bg-white text-black rounded-full flex items-center justify-center">
            <Play size={32} fill="currentColor" />
          </div>
          <SkipForward size={24} />
        </div>
      </div>
    </div>
  );
};

export const BrowserApp: React.FC<{ language: Language }> = ({ language }) => {
  const [url, setUrl] = useState('https://google.com');
  return (
    <div className="bg-white h-full flex flex-col">
      <div className="p-2 bg-gray-100 border-b flex items-center gap-2">
        <div className="flex gap-1">
          <div className="w-3 h-3 bg-red-400 rounded-full" />
          <div className="w-3 h-3 bg-yellow-400 rounded-full" />
          <div className="w-3 h-3 bg-green-400 rounded-full" />
        </div>
        <div className="flex-grow bg-white px-3 py-1 rounded-full border text-sm flex items-center gap-2 text-gray-500">
          <Globe size={14} />
          <input 
            className="outline-none w-full" 
            value={url} 
            onChange={(e) => setUrl(e.target.value)}
          />
        </div>
      </div>
      <div className="flex-grow flex items-center justify-center bg-gray-50 text-gray-400 flex-col gap-4">
        <Globe size={64} className="opacity-20" />
        <p className="text-sm font-medium">Browser simulation for {url}</p>
      </div>
    </div>
  );
};

export const CalendarApp: React.FC<{ language: Language }> = ({ language }) => {
  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  return (
    <div className="bg-white h-full p-6">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold">March 2026</h2>
        <div className="flex gap-4">
          <ChevronLeft size={20} />
          <ChevronRight size={20} />
        </div>
      </div>
      <div className="grid grid-cols-7 gap-4 text-center mb-4">
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => (
          <div key={d} className="text-xs font-bold text-gray-400">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-4 text-center">
        {days.map(d => (
          <div key={d} className={`p-2 rounded-lg text-sm ${d === 28 ? 'bg-blue-600 text-white font-bold' : 'hover:bg-gray-100 text-gray-700'}`}>
            {d}
          </div>
        ))}
      </div>
    </div>
  );
};

export const ClockApp: React.FC<{ language: Language }> = ({ language }) => {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-black h-full flex flex-col items-center justify-center text-white p-8">
      <div className="w-64 h-64 border-4 border-zinc-800 rounded-full flex items-center justify-center relative mb-12">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-1 h-24 bg-white rounded-full origin-bottom" style={{ transform: `rotate(${time.getHours() * 30}deg) translateY(-50%)` }} />
          <div className="w-1 h-32 bg-white rounded-full origin-bottom" style={{ transform: `rotate(${time.getMinutes() * 6}deg) translateY(-50%)` }} />
          <div className="w-0.5 h-32 bg-red-500 rounded-full origin-bottom" style={{ transform: `rotate(${time.getSeconds() * 6}deg) translateY(-50%)` }} />
        </div>
        <div className="w-3 h-3 bg-white rounded-full z-10" />
      </div>
      <div className="text-6xl font-thin tracking-tighter mb-2">
        {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
      </div>
      <div className="text-zinc-500 uppercase tracking-widest text-xs">
        {time.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}
      </div>
    </div>
  );
};

export const Explorer: React.FC<{ language: Language }> = ({ language }) => {
  const t = translations[language].apps.explorer;
  const files = [
    { name: t.documents, type: 'folder' },
    { name: t.pictures, type: 'folder' },
    { name: t.music, type: 'folder' },
    { name: t.videos, type: 'folder' },
    { name: 'notes.txt', type: 'file' },
    { name: 'budget.xlsx', type: 'file' },
  ];

  return (
    <div className="p-4 bg-white h-full">
      <div className="flex items-center gap-4 mb-6 border-b pb-4">
        <div className="flex gap-2">
          <button className="p-1 hover:bg-gray-100 rounded">←</button>
          <button className="p-1 hover:bg-gray-100 rounded">→</button>
        </div>
        <div className="flex-grow bg-gray-100 px-3 py-1 rounded text-sm text-gray-600">
          C:\Users\Admin\{t.desktop}
        </div>
      </div>
      <div className="grid grid-cols-4 sm:grid-cols-6 gap-4">
        {files.map(f => (
          <div key={f.name} className="flex flex-col items-center gap-1 p-2 hover:bg-blue-50 rounded cursor-pointer group">
            {f.type === 'folder' ? (
              <Folder className="w-12 h-12 text-blue-400 group-hover:text-blue-500" />
            ) : (
              <FileText className="w-12 h-12 text-gray-400 group-hover:text-gray-500" />
            )}
            <span className="text-xs text-center truncate w-full">{f.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
