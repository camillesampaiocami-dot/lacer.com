import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Minus, Square, Maximize2, Terminal as TerminalIcon, 
  FileText, Calculator as CalcIcon, Folder, Settings, 
  Globe, Search, Battery, Wifi, Volume2, Clock, 
  LayoutGrid, Power, ShoppingBag, Star, Download,
  MousePointer2, Image as ImageIcon, Palette, Monitor,
  ChevronRight, Info, Camera, Music, Calendar as CalendarIcon
} from 'lucide-react';
import { AppId, WindowState, AppDefinition } from './types';
import { 
  Notepad, Calculator, Terminal, PlayStore, SettingsApp, Explorer,
  CameraApp, GalleryApp, MusicApp, BrowserApp, CalendarApp, ClockApp
} from './components/Apps';
import { Language, translations } from './translations';

// --- Desktop Components ---

const getApps = (language: Language): AppDefinition[] => [
  { id: 'terminal', name: translations[language].apps.terminal.title, icon: <TerminalIcon />, component: Terminal },
  { id: 'notepad', name: translations[language].apps.notepad.title, icon: <FileText />, component: Notepad },
  { id: 'calculator', name: translations[language].apps.calculator.title, icon: <CalcIcon />, component: Calculator },
  { id: 'explorer', name: translations[language].apps.explorer.title, icon: <Folder />, component: Explorer },
  { id: 'playstore', name: translations[language].apps.playstore.title, icon: <ShoppingBag />, component: PlayStore },
  { id: 'camera', name: translations[language].apps.camera.title, icon: <Camera />, component: CameraApp },
  { id: 'gallery', name: translations[language].apps.gallery.title, icon: <ImageIcon />, component: GalleryApp },
  { id: 'music', name: translations[language].apps.music.title, icon: <Music />, component: MusicApp },
  { id: 'browser', name: translations[language].apps.browser.title, icon: <Globe />, component: BrowserApp },
  { id: 'calendar', name: translations[language].apps.calendar.title, icon: <CalendarIcon />, component: CalendarApp },
  { id: 'clock', name: translations[language].apps.clock.title, icon: <Clock />, component: ClockApp },
  { id: 'settings', name: translations[language].apps.settings.title, icon: <Settings />, component: (props: any) => <SettingsApp {...props} /> },
];

export default function Desktop({ language, setLanguage }: { language: Language, setLanguage: (l: Language) => void }) {
  const t = translations[language];
  const APPS = getApps(language);
  const [windows, setWindows] = useState<WindowState[]>([]);
  const [activeWindowId, setActiveWindowId] = useState<string | null>(null);
  const [isStartMenuOpen, setIsStartMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [wallpaper, setWallpaper] = useState('https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1920&q=80');
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number } | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => setMousePos({ x: e.clientX, y: e.clientY });
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    
    // Open welcome window on startup
    setTimeout(() => {
      openApp('explorer');
    }, 500);

    return () => clearInterval(timer);
  }, []);

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY });
  };

  const closeContextMenu = () => setContextMenu(null);

  const openApp = (appId: AppId) => {
    const app = APPS.find(a => a.id === appId);
    if (!app) return;

    const newWindow: WindowState = {
      id: Math.random().toString(36).substr(2, 9),
      appId,
      title: app.name,
      isOpen: true,
      isMinimized: false,
      isMaximized: false,
      zIndex: windows.length + 10,
    };

    setWindows([...windows, newWindow]);
    setActiveWindowId(newWindow.id);
    setIsStartMenuOpen(false);
  };

  const closeWindow = (id: string) => {
    setWindows(windows.filter(w => w.id !== id));
    if (activeWindowId === id) setActiveWindowId(null);
  };

  const focusWindow = (id: string) => {
    setActiveWindowId(id);
    setWindows(windows.map(w => ({
      ...w,
      zIndex: w.id === id ? Math.max(...windows.map(win => win.zIndex)) + 1 : w.zIndex
    })));
  };

  return (
    <div 
      onContextMenu={handleContextMenu}
      onClick={closeContextMenu}
      className="h-screen w-screen overflow-hidden bg-cover bg-center flex flex-col font-sans select-none cursor-none"
      style={{ backgroundImage: `url(${wallpaper})` }}
    >
      {/* Custom Cursor */}
      <motion.div 
        className="fixed top-0 left-0 w-6 h-6 pointer-events-none z-[99999] mix-blend-difference"
        animate={{ x: mousePos.x - 12, y: mousePos.y - 12 }}
        transition={{ type: 'spring', damping: 30, stiffness: 250, mass: 0.5 }}
      >
        <div className="w-full h-full bg-white rounded-full border border-black/20 shadow-lg flex items-center justify-center">
          <div className="w-1.5 h-1.5 bg-black rounded-full" />
        </div>
      </motion.div>

      {/* Desktop Context Menu */}
      <AnimatePresence>
        {contextMenu && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            style={{ top: contextMenu.y, left: contextMenu.x }}
            className="fixed w-56 bg-white/80 backdrop-blur-xl border border-white/20 rounded-xl shadow-2xl p-1.5 z-[10001]"
          >
            <button className="w-full flex items-center justify-between px-3 py-2 hover:bg-blue-500 hover:text-white rounded-lg text-sm transition-colors group">
              <span>{t.desktop.view}</span> <ChevronRight size={14} className="opacity-50 group-hover:opacity-100" />
            </button>
            <button className="w-full flex items-center justify-between px-3 py-2 hover:bg-blue-500 hover:text-white rounded-lg text-sm transition-colors group">
              <span>{t.desktop.sortBy}</span> <ChevronRight size={14} className="opacity-50 group-hover:opacity-100" />
            </button>
            <button className="w-full flex items-center justify-between px-3 py-2 hover:bg-blue-500 hover:text-white rounded-lg text-sm transition-colors">
              <span>{t.desktop.refresh}</span>
            </button>
            <div className="h-[1px] bg-gray-200 my-1 mx-2" />
            <button 
              onClick={() => openApp('settings')}
              className="w-full flex items-center justify-between px-3 py-2 hover:bg-blue-500 hover:text-white rounded-lg text-sm transition-colors"
            >
              <span>{t.desktop.personalize}</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Menu Bar (macOS style) */}
      <div className="h-8 bg-black/20 backdrop-blur-md border-b border-white/5 flex items-center justify-between px-4 z-[9999] text-white text-[13px] font-medium">
        <div className="flex items-center gap-4">
          <button 
            onClick={(e) => { e.stopPropagation(); setIsStartMenuOpen(!isStartMenuOpen); }}
            className="hover:bg-white/10 px-2 rounded transition-colors"
          >
            <LayoutGrid size={16} className="text-blue-400" />
          </button>
          <span className="font-bold">WebOS</span>
          <span className="opacity-80 cursor-default hover:opacity-100">{t.desktop.file}</span>
          <span className="opacity-80 cursor-default hover:opacity-100">{t.desktop.edit}</span>
          <span className="opacity-80 cursor-default hover:opacity-100">{t.desktop.view}</span>
          <span className="opacity-80 cursor-default hover:opacity-100">{t.desktop.go}</span>
          <span className="opacity-80 cursor-default hover:opacity-100">{t.desktop.window}</span>
          <span className="opacity-80 cursor-default hover:opacity-100">{t.desktop.help}</span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 opacity-80">
            <Wifi size={14} />
            <Volume2 size={14} />
            <Battery size={14} />
            <Search size={14} />
          </div>
          <div className="flex items-center gap-2">
            <span>{currentTime.toLocaleTimeString(language === 'pt' ? 'pt-BR' : 'en-US', { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
        </div>
      </div>

      {/* Desktop Area */}
      <div className="flex-grow relative p-4 grid grid-flow-col grid-rows-[repeat(auto-fill,100px)] gap-4 content-start items-start">
        {/* Windows */}
        <AnimatePresence mode="popLayout">
          {windows.map(win => {
            const appDef = APPS.find(a => a.id === win.appId);
            const AppComp = appDef?.component || (() => null);
            return (
              <motion.div
                key={win.id}
                initial={{ opacity: 0, scale: 0.8, y: 50, filter: 'blur(10px)' }}
                animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, scale: 0.8, y: 50, filter: 'blur(10px)' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                style={{ zIndex: win.zIndex }}
                onMouseDown={() => focusWindow(win.id)}
                drag
                dragMomentum={false}
                dragListener={true}
                className={`absolute top-20 left-20 w-[750px] h-[550px] bg-white/95 backdrop-blur-2xl rounded-2xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] overflow-hidden flex flex-col border border-white/40 ${activeWindowId === win.id ? 'ring-2 ring-blue-500/30' : ''}`}
              >
                {/* Title Bar */}
                <div className="h-12 bg-gray-100/40 backdrop-blur-md flex items-center justify-between px-4 cursor-move border-b border-black/5">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-2 mr-3">
                      <button onClick={(e) => { e.stopPropagation(); closeWindow(win.id); }} className="w-3.5 h-3.5 rounded-full bg-[#FF5F57] border border-black/10 hover:brightness-90 transition-all flex items-center justify-center group"><X size={8} className="opacity-0 group-hover:opacity-100" /></button>
                      <button className="w-3.5 h-3.5 rounded-full bg-[#FEBC2E] border border-black/10 hover:brightness-90 transition-all flex items-center justify-center group"><Minus size={8} className="opacity-0 group-hover:opacity-100" /></button>
                      <button className="w-3.5 h-3.5 rounded-full bg-[#28C840] border border-black/10 hover:brightness-90 transition-all flex items-center justify-center group"><Maximize2 size={8} className="opacity-0 group-hover:opacity-100" /></button>
                    </div>
                    <span className="text-gray-400">{React.cloneElement(appDef?.icon as React.ReactElement, { size: 16 })}</span>
                    <span className="text-[13px] font-medium text-gray-600">{win.title}</span>
                  </div>
                </div>
                {/* Content */}
                <div className="flex-grow overflow-hidden">
                  <AppComp window={win} onWallpaperChange={setWallpaper} language={language} setLanguage={setLanguage} />
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* iOS Style Dock */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[10000]">
        <motion.div 
          className="flex items-end gap-3 px-4 py-3 bg-white/20 backdrop-blur-3xl border border-white/20 rounded-[32px] shadow-[0_20px_50px_rgba(0,0,0,0.3)]"
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          transition={{ type: 'spring', damping: 20, stiffness: 100 }}
        >
          {APPS.map(app => {
            const isOpen = windows.some(w => w.appId === app.id);
            const isActive = windows.find(w => w.id === activeWindowId)?.appId === app.id;

            return (
              <div key={app.id} className="relative flex flex-col items-center group">
                <motion.button
                  whileHover={{ scale: 1.2, y: -15 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => openApp(app.id)}
                  className={`w-16 h-16 rounded-[1.25rem] flex items-center justify-center text-white shadow-xl transition-all duration-200 ${
                    app.id === 'terminal' ? 'bg-gradient-to-br from-gray-700 to-black' :
                    app.id === 'notepad' ? 'bg-gradient-to-br from-yellow-400 to-orange-500' :
                    app.id === 'calculator' ? 'bg-gradient-to-br from-blue-400 to-blue-600' :
                    app.id === 'playstore' ? 'bg-gradient-to-br from-green-400 to-emerald-600' :
                    app.id === 'camera' ? 'bg-gradient-to-br from-gray-200 to-gray-400 text-black' :
                    app.id === 'gallery' ? 'bg-gradient-to-br from-blue-300 to-blue-500' :
                    app.id === 'music' ? 'bg-gradient-to-br from-pink-500 to-rose-600' :
                    app.id === 'browser' ? 'bg-gradient-to-br from-blue-400 to-blue-600' :
                    app.id === 'calendar' ? 'bg-gradient-to-br from-red-400 to-red-600' :
                    app.id === 'clock' ? 'bg-gradient-to-br from-zinc-700 to-zinc-900' :
                    app.id === 'settings' ? 'bg-gradient-to-br from-gray-400 to-gray-600' :
                    'bg-gradient-to-br from-blue-500 to-indigo-600'
                  }`}
                >
                  {React.cloneElement(app.icon as React.ReactElement, { size: 32 })}
                </motion.button>
                
                {/* Indicator dot */}
                {isOpen && (
                  <div className={`absolute -bottom-2 w-1.5 h-1.5 rounded-full ${isActive ? 'bg-white w-3' : 'bg-white/50'} transition-all`} />
                )}

                {/* Tooltip */}
                <div className="absolute -top-12 px-3 py-1.5 bg-black/80 backdrop-blur-md text-white text-xs font-medium rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl">
                  {app.name}
                </div>
              </div>
            );
          })}
          
          <div className="w-[1px] h-12 bg-white/20 mx-2 self-center" />

          <motion.button
            whileHover={{ scale: 1.2, y: -15 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => openApp('settings')}
            className="w-16 h-16 rounded-[1.25rem] bg-white/10 backdrop-blur-md flex items-center justify-center text-white/80 hover:text-white transition-all shadow-xl"
          >
            <Settings size={32} />
          </motion.button>
        </motion.div>
      </div>

      {/* Start Menu (Launchpad) */}
      <AnimatePresence>
        {isStartMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="absolute top-10 left-2 w-[450px] bg-gray-900/90 backdrop-blur-3xl rounded-3xl shadow-2xl border border-white/10 overflow-hidden z-[10000]"
          >
            <div className="p-8">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-white text-xl font-bold">{t.desktop.launchpad}</h3>
                <button className="text-sm text-blue-400 hover:underline">{t.desktop.allApps} &gt;</button>
              </div>
              <div className="grid grid-cols-4 gap-6">
                {APPS.map(app => (
                  <button 
                    key={app.id}
                    onClick={() => openApp(app.id)}
                    className="flex flex-col items-center gap-3 p-2 rounded-2xl hover:bg-white/10 transition-colors group"
                  >
                    <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center text-white group-hover:scale-110 transition-transform shadow-lg">
                      {React.cloneElement(app.icon as React.ReactElement, { size: 28 })}
                    </div>
                    <span className="text-white text-xs font-medium">{app.name}</span>
                  </button>
                ))}
              </div>

              <div className="mt-10 pt-8 border-t border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white text-lg font-bold shadow-lg">
                    R
                  </div>
                  <div className="flex flex-col">
                    <span className="text-white font-bold">Roberto</span>
                    <span className="text-white/50 text-xs">{t.desktop.administrator}</span>
                  </div>
                </div>
                <button className="p-3 text-white/50 hover:text-white hover:bg-red-500/20 rounded-full transition-colors">
                  <Power size={24} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
