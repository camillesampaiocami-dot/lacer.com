import React, { ReactNode } from 'react';

export type AppId = 'terminal' | 'notepad' | 'calculator' | 'explorer' | 'settings' | 'browser' | 'playstore' | 'camera' | 'gallery' | 'music' | 'calendar' | 'clock';

export interface WindowState {
  id: string;
  appId: AppId;
  title: string;
  isOpen: boolean;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
}

export interface AppDefinition {
  id: AppId;
  name: string;
  icon: ReactNode;
  component: React.ComponentType<{ window: WindowState }>;
}
