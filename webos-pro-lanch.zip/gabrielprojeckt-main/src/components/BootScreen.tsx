import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { LayoutGrid } from 'lucide-react';

export default function BootScreen({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 200);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100000] bg-zinc-950 flex flex-col items-center justify-center">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="flex flex-col items-center gap-8"
      >
        <div className="w-24 h-24 bg-blue-600 rounded-[2rem] flex items-center justify-center shadow-[0_0_50px_rgba(37,99,235,0.3)]">
          <LayoutGrid size={48} className="text-white" />
        </div>
        
        <div className="flex flex-col items-center gap-2">
          <h1 className="text-white text-3xl font-bold tracking-tighter">WebOS Pro</h1>
          <p className="text-blue-500 text-sm font-mono uppercase tracking-[0.3em]">Lanch OS</p>
        </div>

        <div className="w-64 h-1 bg-white/10 rounded-full overflow-hidden mt-8">
          <motion.div 
            className="h-full bg-blue-500"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
          />
        </div>
        
        <p className="text-white/30 text-[10px] font-mono mt-4 uppercase tracking-widest">
          Initializing Kernel... {Math.round(progress)}%
        </p>
      </motion.div>

      <div className="absolute bottom-12 text-white/10 text-[10px] font-mono uppercase tracking-widest">
        © 2026 WebOS Corporation
      </div>
    </div>
  );
}
