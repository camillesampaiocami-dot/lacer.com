import React from 'react';
import { motion } from 'motion/react';
import { Smartphone, Monitor, Download, ChevronRight, LayoutGrid, Star, Shield, Zap, Globe } from 'lucide-react';
import { Language, translations } from '../translations';

export default function DownloadPage({ language, onBack }: { language: Language, onBack: () => void }) {
  const t = translations[language].apps.settings;
  const d = translations[language].apps.download!;
  const isPt = language === 'pt';

  return (
    <div className="fixed inset-0 z-[100001] bg-white overflow-y-auto font-sans text-gray-900 selection:bg-blue-100 selection:text-blue-900">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-gray-100 px-6 py-4 flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <LayoutGrid size={24} className="text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight">WebOS Pro <span className="text-blue-600">Lanch</span></span>
        </div>
        <div className="flex items-center gap-8 text-sm font-medium text-gray-500">
          <a href="#features" className="hover:text-blue-600 transition-colors">{d.features}</a>
          <a href="#download" className="hover:text-blue-600 transition-colors">Download</a>
          <button 
            onClick={onBack}
            className="bg-gray-900 text-white px-6 py-2.5 rounded-full hover:bg-gray-800 transition-all shadow-lg shadow-gray-900/20 active:scale-95"
          >
            {d.backToSystem}
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative pt-24 pb-32 px-6 overflow-hidden">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-8 border border-blue-100">
              <Star size={14} /> {d.newRelease} v1.0.0
            </div>
            <h1 className="text-7xl font-black tracking-tight leading-[0.9] mb-8">
              {isPt ? 'O Futuro do Seu' : 'The Future of Your'} <br />
              <span className="text-blue-600">{isPt ? 'Desktop e Mobile' : 'Desktop and Mobile'}</span>
            </h1>
            <p className="text-xl text-gray-500 mb-12 max-w-lg leading-relaxed">
              {d.subtitle}
            </p>
            <div className="flex flex-wrap gap-4">
              <a href="#download" className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-3 hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/30 active:scale-95">
                <Download size={20} /> {d.downloadNow}
              </a>
              <button onClick={onBack} className="bg-white text-gray-900 border border-gray-200 px-8 py-4 rounded-2xl font-bold flex items-center gap-3 hover:bg-gray-50 transition-all shadow-sm active:scale-95">
                {d.onlineDemo} <ChevronRight size={20} />
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-gradient-to-tr from-blue-500/20 to-purple-500/20 blur-3xl rounded-full" />
            <img 
              src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1920&q=80" 
              alt="WebOS Pro Screenshot" 
              className="relative w-full rounded-3xl shadow-2xl border border-gray-100"
              referrerPolicy="no-referrer"
            />
          </motion.div>
        </div>
      </header>

      {/* Features */}
      <section id="features" className="py-32 bg-gray-50 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-24">
            <h2 className="text-4xl font-black tracking-tight mb-4">{isPt ? 'Por que escolher o Lanch?' : 'Why choose Lanch?'}</h2>
            <p className="text-gray-500 text-lg">{isPt ? 'Recursos poderosos para usuários modernos.' : 'Powerful features for modern users.'}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: <Zap className="text-amber-500" />, title: isPt ? 'Alta Performance' : 'High Performance', desc: isPt ? 'Otimizado para rodar suave em qualquer hardware.' : 'Optimized to run smooth on any hardware.' },
              { icon: <Shield className="text-green-500" />, title: isPt ? 'Segurança Total' : 'Total Security', desc: isPt ? 'Seus dados protegidos com criptografia de ponta.' : 'Your data protected with high-end encryption.' },
              { icon: <Globe className="text-blue-500" />, title: isPt ? 'Multi-Plataforma' : 'Multi-Platform', desc: isPt ? 'Use no Windows, Android ou diretamente na Web.' : 'Use on Windows, Android or directly on the Web.' },
            ].map((feature, i) => (
              <div key={i} className="bg-white p-10 rounded-3xl border border-gray-100 shadow-sm hover:shadow-xl transition-all group">
                <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-4">{feature.title}</h3>
                <p className="text-gray-500 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Download Section */}
      <section id="download" className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="bg-gray-900 rounded-[4rem] p-16 lg:p-24 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-blue-600/20 to-transparent pointer-events-none" />
            
            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
              <div>
                <h2 className="text-5xl lg:text-6xl font-black tracking-tight mb-8 leading-[1.1]">
                  {d.getStarted}
                </h2>
                <p className="text-xl text-gray-400 mb-12 leading-relaxed">
                  {d.nativeExperience}
                </p>
                <div className="flex items-center gap-6 p-6 bg-white/5 rounded-3xl border border-white/10">
                  <div className="w-12 h-12 bg-blue-500/20 text-blue-400 rounded-xl flex items-center justify-center">
                    <LayoutGrid size={24} />
                  </div>
                  <p className="text-sm text-gray-400">
                    {t.buildNote}
                  </p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 hover:bg-white/10 transition-all group">
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-green-500/20 text-green-400 rounded-2xl flex items-center justify-center">
                        <Smartphone size={28} />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold">{t.androidApk}</h3>
                        <p className="text-gray-500 text-sm">{t.generateApk}</p>
                      </div>
                    </div>
                    <div className="text-xs font-mono text-gray-500">v1.0.0</div>
                  </div>
                  <button className="w-full bg-white text-gray-900 py-4 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-gray-100 transition-all active:scale-95">
                    <Download size={20} /> {isPt ? 'Baixar APK' : 'Download APK'}
                  </button>
                </div>

                <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 hover:bg-white/10 transition-all group">
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-blue-500/20 text-blue-400 rounded-2xl flex items-center justify-center">
                        <Monitor size={28} />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold">{t.windowsExe}</h3>
                        <p className="text-gray-500 text-sm">{t.generateExe}</p>
                      </div>
                    </div>
                    <div className="text-xs font-mono text-gray-500">v1.0.0</div>
                  </div>
                  <button className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/20 active:scale-95">
                    <Download size={20} /> {isPt ? 'Baixar EXE' : 'Download EXE'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-24 border-t border-gray-100 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <LayoutGrid size={18} className="text-white" />
            </div>
            <span className="font-bold">WebOS Pro</span>
          </div>
          <p className="text-gray-500 text-sm">© 2026 WebOS Corporation. All rights reserved.</p>
          <div className="flex items-center gap-6 text-gray-400">
             <a href="#" className="hover:text-blue-600 transition-colors">Privacy</a>
             <a href="#" className="hover:text-blue-600 transition-colors">Terms</a>
             <a href="#" className="hover:text-blue-600 transition-colors">Github</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
